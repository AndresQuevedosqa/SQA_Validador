from .validator import ValidationReport

class Reporter:
    def mostrar(self, report: ValidationReport):
        print(f"\n{'='*68}")
        print(f"  Resultado     : {'PASS ✓' if report.passed else 'FAIL ✗'}")
        print(f"  Filas BD      : {report.filas_bd:,}")
        print(f"  Filas Storage : {report.filas_storage:,}")
        print(f"  Campos OK     : {report.total_ok} / {len(report.campos)}")
        if report.cols_faltantes:
            print(f"  Faltan en ST  : {report.cols_faltantes}")
        print(f"\n  {'Campo':<25} {'BD':>8} {'Storage':>8} {'Complet.':>10}  Estado")
        print(f"  {'-'*65}")
        for c in report.campos:
            print(
                f"  {c.nombre:<25} {c.conteo_bd:>8,} "
                f"{c.conteo_storage:>8,} {c.completitud:>9.1f}%  {c.estado}"
            )
        print(f"{'='*68}\n")

    def guardar_json(self, report: ValidationReport, path: str):
        with open(path, "w", encoding="utf-8") as f:
            f.write(report.model_dump_json(indent=2))
        print(f"Reporte guardado: {path}")