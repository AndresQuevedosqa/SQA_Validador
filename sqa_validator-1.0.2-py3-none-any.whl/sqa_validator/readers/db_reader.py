from pyspark.sql import SparkSession, DataFrame
from .base import BaseReader

class DatabaseReader(BaseReader):
    """Lee de PostgreSQL via JDBC en PySpark"""

    def __init__(self, spark: SparkSession, jdbc_url: str,
                 table: str, user: str, password: str):
        self._spark    = spark
        self._jdbc_url = jdbc_url
        self._table    = table
        self._user     = user
        self._password = password

    def read(self) -> DataFrame:
        return (
            self._spark.read
            .format("jdbc")
            .option("url",      self._jdbc_url)
            .option("dbtable",  self._table)
            .option("user",     self._user)
            .option("password", self._password)
            .option("driver",   "org.postgresql.Driver")
            .option("fetchsize", 10000)
            .load()
        )