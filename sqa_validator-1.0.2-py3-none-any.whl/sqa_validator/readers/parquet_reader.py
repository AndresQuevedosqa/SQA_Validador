from pyspark.sql import SparkSession, DataFrame
from .base import BaseReader

class ParquetFileReader(BaseReader):
    """
    Leer archivos .parquet planos 
    """

    def __init__(self, spark: SparkSession, path: str):
        self._spark = spark
        self._path  = path

    def read(self) -> DataFrame:
        return self._spark.read.parquet(self._path)