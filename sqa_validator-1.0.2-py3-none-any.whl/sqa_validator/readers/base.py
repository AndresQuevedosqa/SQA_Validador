from abc import ABC, abstractmethod
from pyspark.sql import DataFrame

class BaseReader(ABC):
    @abstractmethod
    def read(self) -> DataFrame:
        pass