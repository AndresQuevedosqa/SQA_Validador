from pyspark.sql import SparkSession, DataFrame
from .base import BaseReader

class StorageReader(BaseReader):
    """Lee archivos desde Azure Blob / ADLS via ABFS nativo"""

    def __init__(self, spark: SparkSession, path: str):
        self._spark = spark
        self._path  = path

    def read(self) -> DataFrame:
        ext = self._path.split(".")[-1].lower()
        formatos = {
            "parquet": lambda p: self._spark.read.parquet(p),
            "csv":     lambda p: self._spark.read
                                    .option("header", "true")
                                    .option("inferSchema", "true")
                                    .csv(p),
            "json":    lambda p: self._spark.read.json(p),
            "delta":   lambda p: self._spark.read.format("delta").load(p),
        }
        if ext not in formatos:
            raise ValueError(f"Formato no soportado: {ext}")
        return formatos[ext](self._path)