from __future__ import annotations
from pydantic import BaseModel, computed_field
from pyspark.sql import DataFrame
from pyspark.sql import functions as F


class FieldResult(BaseModel):
    nombre:          str
    conteo_bd:       int
    conteo_storage:  int
    nulos_bd:        int
    nulos_storage:   int
    tipo_bd:         str
    tipo_storage:    str

    @computed_field
    @property
    def estado(self) -> str:
        return "OK" if self.conteo_bd == self.conteo_storage else "FALLO"

    @computed_field
    @property
    def completitud(self) -> float:
        if self.conteo_bd == 0:
            return 100.0
        return round(self.conteo_storage / self.conteo_bd * 100, 2)


class ValidationReport(BaseModel):
    filas_bd:       int
    filas_storage:  int
    campos:         list[FieldResult] = []
    cols_faltantes: list[str]         = []

    @computed_field
    @property
    def passed(self) -> bool:
        return (
            self.filas_bd == self.filas_storage and
            not self.cols_faltantes and
            all(c.estado == "OK" for c in self.campos)
        )

    @computed_field
    @property
    def total_ok(self) -> int:
        return sum(1 for c in self.campos if c.estado == "OK")

    @computed_field
    @property
    def total_fallo(self) -> int:
        return sum(1 for c in self.campos if c.estado == "FALLO")


class Validator:
    """Compara dos DataFrames de Spark campo a campo"""

    def run(self, df_bd: DataFrame, df_st: DataFrame) -> ValidationReport:
        cols_bd = set(df_bd.columns)
        cols_st = set(df_st.columns)

        report = ValidationReport(
            filas_bd       = df_bd.count(),
            filas_storage  = df_st.count(),
            cols_faltantes = list(cols_bd - cols_st),
        )

        for col in sorted(cols_bd & cols_st):
            tipo_bd = dict(df_bd.dtypes)[col]
            tipo_st = dict(df_st.dtypes)[col]

            report.campos.append(FieldResult(
                nombre         = col,
                conteo_bd      = df_bd.filter(F.col(col).isNotNull()).count(),
                conteo_storage = df_st.filter(F.col(col).isNotNull()).count(),
                nulos_bd       = df_bd.filter(F.col(col).isNull()).count(),
                nulos_storage  = df_st.filter(F.col(col).isNull()).count(),
                tipo_bd        = tipo_bd,
                tipo_storage   = tipo_st,
            ))

        return report