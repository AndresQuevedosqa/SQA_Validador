from pydantic_settings import BaseSettings
from pydantic import field_validator

class Config(BaseSettings):
    db_host:        str
    db_port:        int    = 5432
    db_user:        str
    db_password:    str
    db_name:        str
    az_conn_str:    str
    source_table:   str
    dest_container: str
    dest_blob:      str

    @field_validator("source_table")
    @classmethod
    def tabla_con_esquema(cls, v):
        if "." not in v:
            raise ValueError("SOURCE_TABLE debe tener formato esquema.tabla — ej: public.model")
        return v

    @property
    def jdbc_url(self) -> str:
        return f"jdbc:postgresql://{self.db_host}:{self.db_port}/{self.db_name}"
    
    @property
    def sqlalchemy_url(self) -> str:
        return (
        f"postgresql+psycopg2://"
        f"{self.db_user}:{self.db_password}"
        f"@{self.db_host}:{self.db_port}/{self.db_name}"
     )

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}